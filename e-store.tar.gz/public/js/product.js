$(document).ready(function() {
	$("#relevant-products-carousel").lightSlider({
		item: 4,
	});
});