<!DOCTYPE html>
<html>

<head>
    <title>Order Confirmation</title>
    <style type="text/css">
    body {
        font-family: Nunito, sans-serif;
    }

    #logo {
        padding: 10px;
        background: #252d6c;
        position: fixed;
        right: 0;
        top: 10;
    }

    #consignor td p,
    #customer-details td p,
    #note td p {
        margin: 7px 0;
    }

    .order-summary-header,
    .note-ground-total {
        background: LightGrey;
    }

    .bold {
        font-weight: bold;
    }

    .text-align-right {
        text-align: right;
    }

    </style>
</head>

<body>
    <table cellpadding="10" cellspacing="0">
        <tr id="consignor">
            <td>
                <p class="bold">Hiroki's Liquor</p>
                <p>123 King Street</p>
                <p>Example Hills</p>
                <p>QLD, 4000</p>
            </td>
            <td>
                <img id="logo" src="<?php echo e(asset('images/logo.png')); ?>">
            </td>
        </tr>
        <tr id="customer-details">
            <td width="300" valign="top">
                <p class="bold">Ship to</p>
                <p><?php echo e($order->delivery_address_1); ?> <?php echo e($order->delivery_address_2); ?> <?php echo e($order->delivery_suburb); ?>, <?php echo e($order->delivery_state); ?>, <?php echo e($order->delivery_postcode); ?></p>
                <p class="bold">Bill to</p>
                <p><?php echo e($order->first_name); ?> <?php echo e($order->last_name); ?></p>
                <p><?php echo e($order->getBillingAddress1()); ?> <?php echo e($order->getBillingAddress2()); ?> <?php echo e($order->getBillingSuburb()); ?>, <?php echo e($order->getBillingState()); ?>, <?php echo e($order->getBillingPostcode()); ?></p>
            </td>
            <td width="220" valign="top">
                <p><strong>Order Number :</strong>&nbsp; <?php echo e($order->confirmation_number); ?></p>
                <p><strong>Ordered Date :</strong>&nbsp; <?php echo e($order->orderedDate); ?></p>
            </td>
        </tr>
        <tr id="order-summary">
            <td colspan="2">
                <p><strong>Order Summary</strong></p>
                <table cellpadding="5" cellspacing="0">
                    <tr class="order-summary-header">
                        <th width="170">Item</th>
                        <th width="100" class="text-align-right">Item Price</th>
                        <th width="100" class="text-align-right">Quantity</th>
                        <th width="130" class="text-align-right">Line Total</th>
                    </tr>
                    <?php $__currentLoopData = $order->getOrderSummary(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->name); ?></td>
                        <td class="text-align-right">$ <?php echo e($item->price); ?></td>
                        <td class="text-align-right">× <?php echo e($item->qty); ?></td>
                        <td class="text-align-right"><strong>$<?php echo e($item->total_price); ?></strong></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr class="order-summary-total">
                        <td></td>
                        <td></td>
                        <td></td>
                        <td class="text-align-right"><strong>Total :&nbsp;$<?php echo e($order->formatted_total_price); ?></strong></td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr class="note">
            <td width="260">
                <p class="bold">NOTES/MEMO</p>
                <p>Standard Delivery</p>
                <p>It will be delivered by <?php echo e($order->deliveryDue); ?></p>
            </td>
            <td width="260">
                <table cellpadding="5" cellspacing="0">
                    <tr>
                        <td width="120">SUBTOTAL</td>
                        <td width="80" class="text-align-right">$<?php echo e($order->formatted_total_price); ?></td>
                    </tr>
                    <tr>
                        <td>Delivery Fee</td>
                        <td class="text-align-right">$ 0.00</td>
                    </tr>
                    <tr class="note-ground-total">
                        <td><strong>TOTAL</strong></td>
                        <td class="text-align-right"><strong>$<?php echo e($order->formatted_total_price); ?></strong></td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>

</html>
