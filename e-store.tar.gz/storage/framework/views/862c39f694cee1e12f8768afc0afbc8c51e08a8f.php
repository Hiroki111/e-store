<?php $__env->startSection('title', $productType->name); ?>
<?php $__env->startSection('content'); ?>
<script type="text/javascript" src="/js/producttype.js"></script>
<div id="breadcrumbs" class="container">
    <ul>
        <li>
            <a href="/">Home</a>
            <span>›</span>
        </li>
        <li><?php echo e($productType->name); ?></li>
    </ul>
</div>
<div class="container product-type">
    <div class="product-type-wrapper">
        <div class="filter-column">
            <?php if(!$selectedFilter->isEmpty()): ?>
            <div class="selected-filter">
                <h5 class="font-weight-bold">You have chosen:</h5>
                <?php $__currentLoopData = $selectedFilter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <hr>
                <h6 class="font-weight-bold"><?php echo e($category); ?><i class="pull-right remove-selected-filter fa fa-times" data-remove-category="<?php echo e($category); ?>"></i></h6>
                <ul>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($item); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
            <div class="filter-items">
                <div class="product-filter">
                    <div class="row no-gutters filter-header">
                        <div class="col-8">
                            <h4 class="font-weight-bold">Filter</h4>
                        </div>
                        <div class="col-4">
                            <button id="apply-filter-btn" class="btn btn-danger pull-right">Apply</button>
                        </div>
                    </div>
                    <hr>
                    <div class="filter-body">
                        <div class="price-range">
                            <div class="price-range-heading-wrapper">
                                <h5 class="filter-keyword font-weight-bold" data-filter-keyword="price-range">Price Range<i class="pull-right fa fa-minus"></i></h5>
                            </div>
                            <ul id="price-range-ul">
                                <?php $__currentLoopData = $priceRanges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $priceRange): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <label>
                                        <input type="checkbox" class="price-range-checkbox" data-price-min="<?php echo e($priceRange->min); ?>" data-price-max="<?php echo e($priceRange->max); ?>">
                                        $<?php echo e($priceRange->min); ?> - $<?php echo e($priceRange->max); ?>

                                        <span>(<?php echo e($priceRange->qty); ?>)</span>
                                    </label>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="country">
                            <div class="country-heading-wrapper">
                                <h5 class="filter-keyword font-weight-bold" data-filter-keyword="country">Country<i class="pull-right fa fa-plus"></i></h5>
                            </div>
                            <ul id="country-ul">
                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <label>
                                        <input type="checkbox" class="country-checkbox" data-country-name="<?php echo e($country->url_safe_name); ?>">
                                        <?php echo e($country->name); ?>

                                        <span>(<?php echo e($country->qty); ?>)</span>
                                    </label>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="brand">
                            <h5 class="filter-keyword font-weight-bold" data-filter-keyword="brand">Brand<i class="pull-right fa fa-plus"></i></h5>
                            <ul id="brand-ul">
                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <label>
                                        <input type="checkbox" class="brand-checkbox" data-brand-name="<?php echo e($brand->url_safe_name); ?>">
                                        <?php echo e($brand->name); ?>

                                        <span>(<?php echo e($brand->qty); ?>)</span>
                                    </label>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="item-column">
            <h1 id="selected-product-type" class="font-weight-bold text-uppercase"><?php echo e($productType->name); ?></h1>
            <div class="row no-gutters sort-items-wrapper">
                <div class="col-2 sort-by">Sort By</div>
                <div class="col-5">
                    <select id="sort-items" class="custom-select">
                        <option data-column="name" data-order="asc">Name (A - Z)</option>
                        <option data-column="name" data-order="desc">Name (Z - A)</option>
                        <option data-column="price" data-order="asc">Price (Low to High)</option>
                        <option data-column="price" data-order="desc">Price (High to Low)</option>
                    </select>
                </div>
            </div>
            <div class="row no-gutters products-found"><?php echo e($products->total()); ?> products found</div>
            <div class="row">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item">
                    <div class="card mb-4 shadow-sm">
                        <a href="/product/<?php echo e($product->hashed_id); ?>">
                            <div class="card-img-frame">
                                <img class="card-img-top" src="<?php echo e($product->src); ?>">
                            </div>
                        </a>
                        <div class="card-body text-center">
                            <h5 class="card-text"><?php echo e($product->name); ?></h5>
                            <div class="flex-wrapper flex-wrapper-first">
                                <div class="product-tile-price-big">
                                    <div class="price-bundle-new">
                                        <span class="price">
                                            <span class="currency">$</span>
                                            <?php echo e($product->dollars); ?>

                                            <span class="cents">.<?php echo e($product->cents); ?></span>
                                        </span>
                                    </div>
                                    <div class="price-des">Each</div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <button type="button" class="btn btn-sm btn-outline-secondary update-qty-btn" data-update-qty="-1" data-item-type="product" data-item-id="<?php echo e($product->hashed_id); ?>">-</button>
                                    </div>
                                    <input type="number" id="product-<?php echo e($product->hashed_id); ?>" min="1" max="50" value="1" class="form-control add-item-counter">
                                    <div class="input-group-append">
                                        <button type="button" class="btn btn-sm btn-outline-secondary update-qty-btn" data-update-qty="1" data-item-type="product" data-item-id="<?php echo e($product->hashed_id); ?>">+</button>
                                    </div>
                                </div>
                            </div>
                            <div class="input-group">
                                <button data-item-type="product" data-item-id="<?php echo e($product->hashed_id); ?>" data-item-src="<?php echo e($product->src); ?>" type="button" class="btn add-item add-to-cart-button">Add to Cart</button>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="product-type-pagination"><?php echo e($products->links()); ?></div>
        </div>
    </div>
    <?php echo $__env->make('www.layout.addeditem', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('www.layout.cartbutton', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('www.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>