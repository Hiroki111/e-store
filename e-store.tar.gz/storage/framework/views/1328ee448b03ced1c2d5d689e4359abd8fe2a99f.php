<?php $__env->startSection('title', '404'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 style="margin-top: 20px">Sorry, we can't find that page.</h2>
    <p>Please try again or contact our customer service team directly.</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('www.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>