<?php $__env->startSection('title', 'Checkout - View Cart'); ?>
<?php $__env->startSection('content'); ?>
<div class="container empty-cart">
    <div class="row">
        <div class="col-10 offset-md-1 message-area">
            <h3 class="font-weight-bold font-arial">View Cart</h3>
            <p>Your shopping cart is empty.</p>
        </div>
        <hr>
        <div class="col-12 button-area">
            <span><a href="/" class="viewcart-link">Continue Shopping</a></span>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('www.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>