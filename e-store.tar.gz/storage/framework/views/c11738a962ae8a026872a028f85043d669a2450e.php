<?php $__env->startSection('title', 'Order Confirmation'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row" style="padding-top: 40px;">
        <div class="col-md-8">
            <div style="margin-bottom: 1rem;">
                <a href="/confirmation/<?php echo e($order->hashedId); ?>/pdf" target="_blank" style="float: right;">Print invoice</a>
                <h2 class="font-weight-bold">Thank you for shopping with us!</h2>
                <h2 class="font-weight-bold">Your order has been placed.</h2>
            </div>
            <div>
                <p class="font-weight-bold">We received your order <span style="color: #3490dc;"><?php echo e($order->confirmation_number); ?></span> and now it is in process.</p>
                <p class="font-weight-bold">Order Confirmation Email</p>
                <p>We've sent you an order confirmation email.</p>
                <p class="font-weight-bold">Cancellation Process</p>
                <p>If any of your details were incorrect, you can cancel the order within <strong>12 hours of order</strong>. Contact us with cancel@hirokisliquor.com</p>
                <hr />
            </div>
            <div>
                <h4 class="font-arial"><strong class="font-arial">Order Number:</strong>&nbsp; <?php echo e($order->confirmation_number); ?></h4>
                <hr />
            </div>
            <div class="row">
                <div class="col-md-6">
                    <h5 class="font-arial font-weight-bold">Delivery For</h5>
                    <p>Name:&nbsp;<?php echo e($order->first_name); ?> <?php echo e($order->last_name); ?></p>
                    <p>Phone:&nbsp;<?php echo e($order->phone); ?></p>
                    <p>Email:&nbsp;<?php echo e($order->email); ?></p>
                </div>
                <div class="col-md-6">
                    <h5 class="font-arial font-weight-bold">Delivery Method</h5>
                    <p>Standard Delivery</p>
                    <p>It will be delivered by <?php echo e($order->deliveryDue); ?>, between 6am and 7pm</p>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <h5 class="font-arial font-weight-bold">Delivery Address</h5>
                    <p><?php echo e($order->delivery_address_1); ?> <?php echo e($order->delivery_address_2); ?></p>
                    <p><?php echo e($order->delivery_suburb); ?> <?php echo e($order->delivery_state); ?> <?php echo e($order->delivery_postcode); ?></p>
                </div>
                <div class="col-md-6">
                    <h5 class="font-arial font-weight-bold">Billing Address</h5>
                    <p><?php echo e($order->getBillingAddress1()); ?> <?php echo e($order->getBillingAddress2()); ?></p>
                    <p><?php echo e($order->getBillingSuburb()); ?> <?php echo e($order->getBillingState()); ?> <?php echo e($order->getBillingPostcode()); ?></p>
                </div>
                <hr />
            </div>
        </div>
        <div class="col-md-4">
            <?php echo $__env->make('www.util.ordersummary', ['items' => $order->getOrderSummary(), 'totalPrice' => $order->formatted_total_price], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="col-md-12">
            <hr />
            <p>You will receive an order confirmation email with the invoice shortly.</p>
            <p>You can safely close this window, or go back to <a href="/">the top page</a></p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('www.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>