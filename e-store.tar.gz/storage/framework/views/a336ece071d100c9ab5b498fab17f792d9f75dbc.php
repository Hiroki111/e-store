<?php $__env->startSection('title', 'Checkout - View Cart'); ?>
<?php $__env->startSection('content'); ?>
<script type="text/javascript" src="/js/viewcart.js"></script>
<div class="viewcart">
    <div class="viewcart-wrapper">
        <h3 class="font-weight-bold font-arial page-title">View Cart</h3>
        <div class="item-wrapper">
            <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <hr />
            <div class="item" id="<?php echo e($item->type); ?>-<?php echo e($item->id); ?>-tr">
                <div class="item-info-wrap">
                    <div class="item-img">
                        <a href="<?php echo e($item->url); ?>"><img src="<?php echo e($item->src); ?>"></a>
                    </div>
                    <div class="item-info">
                        <h5 class="font-weight-bold font-arial"><a class="item-name" href="<?php echo e($item->url); ?>"><?php echo e($item->name); ?></a></h5>
                        <div class="each-price-wrap">
                            <span class="each-price">Each $<?php echo e($item->price); ?></span>
                        </div>
                    </div>
                </div>
                <div class="item-checkout-info">
                    <div class="quantity-and-update">
                        <div class="quantity">
                            <span class="input-group-text" id="basic-addon1">Quantity</span>
                            <input type="number" class="form-control item-qty-input" name="<?php echo e($item->type); ?>-<?php echo e($item->id); ?>" data-type="<?php echo e($item->type); ?>" data-id="<?php echo e($item->id); ?>" data-price="<?php echo e($item->price); ?>" min="1" max="50" value="<?php echo e($item->qty); ?>" style="text-align: center; max-width: 70px;">
                        </div>
                        <div class="update-button">
                            <button class="update-item-btn btn" data-type="<?php echo e($item->type); ?>" data-id="<?php echo e($item->id); ?>" style="color: blue; padding: 0; display: none;"><i class="fa fa-cart-plus" aria-hidden="true" style="padding-right: 5px;"></i>Update</button>
                        </div>
                    </div>
                    <div>
                        <div class="price">
                            <p class="font-weight-bold" data-total-price="<?php echo e($item->type); ?><?php echo e($item->id); ?>">$<?php echo e($item->total_price); ?></p>
                        </div>
                        <div class="remove-button">
                            <button class="remove-item-btn btn" data-type="<?php echo e($item->type); ?>" data-id="<?php echo e($item->id); ?>" style="color: red; padding: 0;"><i class="fa fa-times" aria-hidden="true" style="padding-right: 5px;"></i>Remove</button>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <hr>
        <div class="botton-heading">
            <h3 id="ground-total" class="font-weight-bold font-arial">Total $<?php echo e($cart->getTotalPrice()); ?></h3>
        </div>
        <div class="botton-heading">
            <h5 id="total-qty" class="font-weight-bold"><?php echo e($cart->count); ?> <?php if($cart->count > 1): ?> items <?php else: ?> item <?php endif; ?></h5>
        </div>
        <div class="botton-heading">
            <span class="continue-shopping-span"><a href="/" class="viewcart-link">Continue Shopping</a> OR <button class="checkout-btn btn font-weight-bold"><a href="/checkout-option" class="viewcart-link">Checkout</a></button></span>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('www.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>