<footer>
	<div class="container">
	<span class="text-muted">Terms and Conditions, Privacy and Security Policy. © Copyright Hiroki's Liquor 2018. All rights reserved.</span>
	</div>
</footer>
