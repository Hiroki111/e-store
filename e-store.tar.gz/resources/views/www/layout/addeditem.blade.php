<div id="added-item">
	<div class="card">
		<img id="added-item-img" class="card-img-top" src="">
		<div class="card-body text-center">
			<h5 id="added-item-text" class="card-text"></h5>
		</div>
	</div>
</div>
