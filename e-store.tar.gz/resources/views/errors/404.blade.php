@extends('www.layout.master')
@section('title', '404')
@section('content')
<div class="container">
    <h2 style="margin-top: 20px">Sorry, we can't find that page.</h2>
    <p>Please try again or contact our customer service team directly.</p>
</div>
@endsection
