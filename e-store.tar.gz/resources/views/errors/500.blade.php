@extends('www.layout.master')
@section('title', '500')
@section('content')
<div class="container">
    <h2 style="margin-top: 20px">Sorry, an internal error occurred.</h2>
    <p>Please try again or contact our customer service team directly.</p>
</div>
@endsection
