require('./bootstrap');
require('./typeahead');