<?php

namespace App\Http\Controllers;

class CheckoutOptionController extends Controller
{
    public function index()
    {
        return view('www.checkoutoption');
    }
}
