<?php

namespace App\Http\Controllers;

class OrderAndPaymentController extends Controller
{
    public function index()
    {
        return view('www.orderandpayment');
    }
}
