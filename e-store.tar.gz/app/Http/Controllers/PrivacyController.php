<?php

namespace App\Http\Controllers;

class PrivacyController extends Controller
{
    public function index()
    {
        return view('www.privacy');
    }
}
