<?php

namespace App\Http\Controllers;

class ClickAndCollectController extends Controller
{
    public function index()
    {
        return view('www.clickandcollect');
    }
}
